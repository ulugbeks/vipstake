import './style.scss';

export default class H2 {
    constructor(data) {
        this.data = data;
        this.id = data.id;
        this.node = document.getElementById(this.id);
        this.handleBlockEvents();
    }

    handleBlockEvents() {
        document.getElementById(this.id).addEventListener('keypress', function(event) {
            if (event.key === 'Enter') {
                document.execCommand('insertLineBreak');
                event.preventDefault();
            }
        });
    }
}