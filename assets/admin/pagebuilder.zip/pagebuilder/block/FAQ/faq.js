import stringToNode from "../../components/htmlParser";
import './style.scss'
import ContextMenu from "../../window/ContextMenu";

export default class FAQ {
    constructor(data) {
        this.data = data;
        this.id = data.id;
        this.node = document.getElementById(this.id);
        this.handleBlockEvents();
        this.contextMenu = new ContextMenu(this.node.querySelector('.pb__context-menu'));
        this.selectedItem = null;
    }

    handleBlockEvents() {
        const addButton = document.getElementById(this.data.id).querySelector('[data-action="add-faq-item"]');
        const self = this;
        addButton.addEventListener('click', addListItem)
        this.node.querySelector('[data-action="delete-item"]').addEventListener('click', () => this.handleItemDelete())

        function addListItem() {
            const prototype = stringToNode(self.data.prototype, false);
            prototype.querySelector('.accordion__item-header--button').addEventListener('click', () => self.handleItemCollapse(prototype))
            prototype.addEventListener('contextmenu', (event) => self.handleItemRightClick(event));
            self.node.querySelector('.accordion').append(prototype);
        }
    }

    handleItemCollapse(item) {
        if (item.classList.contains('show')) {
            item.classList.remove('show');
            return;
        }

        item.classList.add('show');
    }

    handleItemRightClick(event) {
        if(event.target.classList.contains('accordion-item')){
            this.selectedItem = event.target;
        } else {
           this.selectedItem = event.target.closest('.accordion__item');
        }

        this.contextMenu.open(event);
    }

    handleItemDelete() {
        if(this.selectedItem){
            this.selectedItem.remove();
        }

        this.contextMenu.close();
    }
}