export default class ColorList {
    constructor(data) {
        this.data = data;
        this.id = data.id;
        this.node = document.getElementById(this.id);
        this.handleBlockEvents();
    }

    handleBlockEvents() {
        const editableList = this.node.querySelector('.color-list');

        editableList.addEventListener('keydown', (event) => {
            if (event.key === 'Enter') {
                event.preventDefault(); // предотвращаем стандартное поведение Enter
                insertNewListItem();
            }
        });

        function insertNewListItem() {
            const newListItem = document.createElement('li');
            newListItem.textContent += '- text';
            const newSpan = document.createElement('span');
            newSpan.textContent = 'Enter';
            newListItem.prepend(newSpan);

            editableList.appendChild(newListItem);

            // Устанавливаем курсор внутрь нового span
            setCursorInElement(newSpan);
        }

        function setCursorInElement(element) {
            const range = document.createRange();
            const sel = window.getSelection();
            range.setStart(element, 1);
            range.collapse(true);
            sel.removeAllRanges();
            sel.addRange(range);
            element.focus();
        }
    }
}