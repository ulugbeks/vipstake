import './style.scss';
import ContextMenu from "../../window/ContextMenu";

export default class IconLink {
    constructor(data) {
        this.data = data;
        this.id = data.id;
        this.node = document.getElementById(this.id);
        this.linkModal = new ContextMenu(this.node.querySelector('.link-modal'));
        this.link = this.node.querySelector('.lc__link');
        this.handleBlockEvents();
    }

    handleBlockEvents() {
        this.node.querySelector('.lc__link').addEventListener('contextmenu', (event) => this.handleLinkRightClick(event));
        this.node.querySelector('.link-modal input').addEventListener('keydown', (event) => this.handleUrlInput(event));
        const block = this.node;
        const uploadArea = block.querySelector('.pb__image-block_dropzone');
        const fileInput = block.querySelector('.pb__image-block_input');
        const preview = block.querySelector('.pb__image-block_preview');
        const existingImageUrl = ""; // Замените на реальный URL или оставьте пустым

        // Показать превью, если есть существующее изображение
        if (existingImageUrl) {
            showPreview(existingImageUrl);
        }

        uploadArea.addEventListener('click', () => {
            fileInput.click();
        });

        fileInput.addEventListener('change', (event) => {
            handleFiles(event.target.files);
        });

        uploadArea.addEventListener('dragover', (event) => {
            event.preventDefault();
            uploadArea.classList.add('dragover');
        });

        uploadArea.addEventListener('dragleave', () => {
            uploadArea.classList.remove('dragover');
        });

        uploadArea.addEventListener('drop', (event) => {
            event.preventDefault();
            uploadArea.classList.remove('dragover');
            handleFiles(event.dataTransfer.files);
        });

        function handleFiles(files) {
            const file = files[0];
            if (file && file.type.startsWith('image/')) {
                const reader = new FileReader();
                reader.onload = (e) => {
                    showPreview(e.target.result);
                };
                reader.readAsDataURL(file);
            }
        }

        function showPreview(imageSrc) {
            preview.innerHTML = `<img src="${imageSrc}" alt="Image preview">`;
            uploadArea.style.display = 'none';
            preview.style.display = 'block';

            // Добавить обработчик клика на превью
            preview.querySelector('img').addEventListener('click', () => {
                fileInput.click();
            });
        }
    }

    handleLinkRightClick(e) {
        this.linkModal.open(e);
    }

    handleUrlInput(event) {
        if (event.key === 'Enter') {
            event.preventDefault();
            const value = event.target.value;
            this.link.setAttribute('src', value);
            this.linkModal.close();
        }
    }
}