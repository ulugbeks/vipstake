import stringToNode from "../../components/htmlParser";
import './style.scss'

export default class LevelList {
    constructor(data) {
        this.data = data;
        this.id = data.id;
        this.node = document.getElementById(this.id);
        this.handleBlockEvents();
    }

    handleBlockEvents() {
        const addButton = document.getElementById(this.data.id).querySelector('[data-action="add-list-item"]');
        const self = this;

        addButton.addEventListener('click', addListItem)

        function addListItem() {
            const prototype = stringToNode(self.data.prototype, false);
            self.node.querySelector('.level-list').append(prototype);
        }
    }
}