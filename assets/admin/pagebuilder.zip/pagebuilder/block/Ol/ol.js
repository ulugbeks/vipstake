import './style.scss';

export default class Ol {
    constructor(data) {
        this.data = data;
        this.id = data.id;
        this.node = document.getElementById(this.id);
        this.handleBlockEvents();
    }

    handleBlockEvents() {

    }
}